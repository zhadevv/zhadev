import { DonghuaItem } from '@/lib/api';
import { DonghuaCard } from './card/DonghuaCard';
import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HomeSectionProps {
  title: string;
  donghuas: DonghuaItem[];
  viewAllHref?: string;
  gridCols?: number;
  className?: string;
}

export function HomeSection({ 
  title, 
  donghuas, 
  viewAllHref, 
  gridCols = 6,
  className 
}: HomeSectionProps) {
  if (donghuas.length === 0) return null;

  const gridClasses = {
    2: 'grid-cols-2',
    3: 'grid-cols-2 sm:grid-cols-3',
    4: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4',
    5: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-5',
    6: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6'
  };

  return (
    <section className={cn('mb-12', className)}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-text-primary">
          {title}
        </h2>
        
        {viewAllHref && (
          <Link
            href={viewAllHref}
            className="flex items-center space-x-1 text-primary hover:text-primary/80 transition-colors font-medium"
          >
            <span>Lihat Semua</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        )}
      </div>

      <div className={cn('grid gap-4', gridClasses[gridCols as keyof typeof gridClasses])}>
        {donghuas.map((donghua) => (
          <DonghuaCard
            key={donghua.slug}
            donghua={donghua}
            size="md"
            showType={true}
          />
        ))}
      </div>
    </section>
  );
}