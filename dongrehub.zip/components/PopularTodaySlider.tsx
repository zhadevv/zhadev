'use client';

import { useState, useEffect } from 'react';
import { DonghuaItem } from '@/lib/api';
import { DonghuaCard } from './card/DonghuaCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PopularTodaySliderProps {
  donghuas: DonghuaItem[];
  className?: string;
}

export function PopularTodaySlider({ donghuas, className }: PopularTodaySliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const itemsPerView = 6;
  const totalSlides = Math.ceil(donghuas.length / itemsPerView);

  useEffect(() => {
    if (!isAutoPlaying || totalSlides <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % totalSlides);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, totalSlides]);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const visibleDonghuas = donghuas.slice(
    currentIndex * itemsPerView,
    (currentIndex + 1) * itemsPerView
  );

  if (donghuas.length === 0) return null;

  return (
    <div 
      className={cn('relative', className)}
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-text-primary">
          Populer Hari Ini
        </h2>
        
        {totalSlides > 1 && (
          <div className="flex items-center space-x-2">
            <button
              onClick={prevSlide}
              className="p-2 rounded-lg bg-surface border border-border hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              aria-label="Slide sebelumnya"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <button
              onClick={nextSlide}
              className="p-2 rounded-lg bg-surface border border-border hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              aria-label="Slide berikutnya"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      <div className="relative overflow-hidden">
        <div 
          className="transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {visibleDonghuas.map((donghua) => (
              <DonghuaCard
                key={donghua.slug}
                donghua={donghua}
                size="md"
                showType={true}
              />
            ))}
          </div>
        </div>
      </div>

      {totalSlides > 1 && (
        <div className="flex justify-center mt-6 space-x-2">
          {Array.from({ length: totalSlides }).map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={cn(
                'w-3 h-3 rounded-full transition-all duration-300',
                index === currentIndex
                  ? 'bg-primary'
                  : 'bg-border hover:bg-gray-400'
              )}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}