'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SearchInputProps {
  onClose?: () => void;
  className?: string;
}

export function SearchInput({ onClose, className }: SearchInputProps) {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/search/${encodeURIComponent(query.trim())}`);
      setQuery('');
      onClose?.();
    }
  };

  const handleClear = () => {
    setQuery('');
    inputRef.current?.focus();
  };

  return (
    <form 
      onSubmit={handleSubmit}
      className={cn('relative w-full max-w-md', className)}
    >
      <div className={cn(
        'relative flex items-center transition-all duration-200',
        isFocused && 'ring-2 ring-primary/20'
      )}>
        <Search className="absolute left-3 w-5 h-5 text-text-secondary" />
        
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder="Cari donghua..."
          className="w-full pl-10 pr-10 py-3 rounded-lg border border-border bg-surface text-text-primary placeholder-text-secondary focus:outline-none focus:border-primary transition-colors"
        />
        
        {query && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute right-3 p-1 text-text-secondary hover:text-text-primary transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          className="absolute -right-12 top-1/2 transform -translate-y-1/2 p-2 text-text-secondary hover:text-text-primary transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      )}
    </form>
  );
}