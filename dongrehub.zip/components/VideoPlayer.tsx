'use client';

import { useState, useRef, useEffect } from 'react';
import { StreamData } from '@/lib/api';
import { cn } from '@/lib/utils';

interface VideoPlayerProps {
  streamData: StreamData;
  className?: string;
}

export function VideoPlayer({ streamData, className }: VideoPlayerProps) {
  const [currentServer, setCurrentServer] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const playerRef = useRef<HTMLDivElement>(null);

  const decodeEmbed = (embedData: string) => {
    try {
      return atob(embedData);
    } catch {
      return '';
    }
  };

  const currentServerData = streamData.servers[currentServer];

  const toggleFullscreen = () => {
    if (!playerRef.current) return;

    if (!document.fullscreenElement) {
      playerRef.current.requestFullscreen().then(() => {
        setIsFullscreen(true);
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      });
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  return (
    <div className={cn('bg-surface rounded-lg shadow-lg overflow-hidden', className)}>
      <div 
        ref={playerRef}
        className={cn(
          'relative bg-black',
          isFullscreen ? 'fixed inset-0 z-50' : 'aspect-video'
        )}
      >
        {currentServerData ? (
          <div
            dangerouslySetInnerHTML={{
              __html: decodeEmbed(currentServerData.embed_data),
            }}
            className={cn('w-full h-full', isFullscreen && 'h-screen')}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-white">
            <div className="text-center">
              <p className="text-lg mb-2">Video tidak tersedia</p>
              <p className="text-sm text-gray-400">
                Silakan coba server lain
              </p>
            </div>
          </div>
        )}

        {!isFullscreen && (
          <button
            onClick={toggleFullscreen}
            className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded hover:bg-black/70 transition-colors"
            aria-label="Fullscreen"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
            </svg>
          </button>
        )}
      </div>

      <div className="p-4 border-t border-border">
        <div className="flex flex-wrap gap-2 mb-4">
          {streamData.servers.map((server, index) => (
            <button
              key={server.data_index}
              onClick={() => setCurrentServer(index)}
              className={cn(
                'px-3 py-1 rounded text-sm font-medium transition-colors',
                index === currentServer
                  ? 'bg-primary text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-text-secondary hover:bg-gray-300 dark:hover:bg-gray-600'
              )}
            >
              {server.name}
            </button>
          ))}
        </div>

        <div>
          <h1 className="text-xl font-bold text-text-primary mb-2">
            {streamData.title}
          </h1>
          <p className="text-text-secondary text-sm">
            Episode {streamData.episode_number}
          </p>
        </div>
      </div>
    </div>
  );
}