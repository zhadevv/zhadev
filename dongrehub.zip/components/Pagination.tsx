'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  baseUrl: string;
  className?: string;
}

export function Pagination({ 
  currentPage, 
  totalPages, 
  baseUrl,
  className 
}: PaginationProps) {
  const searchParams = useSearchParams();
  
  const createPageUrl = (page: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set('page', page.toString());
    return `${baseUrl}?${params.toString()}`;
  };

  const getVisiblePages = () => {
    const pages = [];
    const showPages = 5;
    
    let start = Math.max(1, currentPage - Math.floor(showPages / 2));
    let end = Math.min(totalPages, start + showPages - 1);
    
    if (end - start + 1 < showPages) {
      start = Math.max(1, end - showPages + 1);
    }
    
    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    
    return pages;
  };

  if (totalPages <= 1) return null;

  const visiblePages = getVisiblePages();

  return (
    <div className={cn('flex justify-center items-center space-x-2', className)}>
      {currentPage > 1 && (
        <Link
          href={createPageUrl(currentPage - 1)}
          className="flex items-center px-3 py-2 rounded-lg bg-surface border border-border hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-text-secondary hover:text-text-primary"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          <span className="hidden sm:block">Sebelumnya</span>
        </Link>
      )}

      {visiblePages[0] > 1 && (
        <>
          <Link
            href={createPageUrl(1)}
            className={cn(
              'px-3 py-2 rounded-lg border transition-colors',
              'bg-surface border-border hover:bg-gray-50 dark:hover:bg-gray-700',
              'text-text-secondary hover:text-text-primary'
            )}
          >
            1
          </Link>
          {visiblePages[0] > 2 && (
            <span className="px-2 text-text-secondary">...</span>
          )}
        </>
      )}

      {visiblePages.map((page) => (
        <Link
          key={page}
          href={createPageUrl(page)}
          className={cn(
            'px-3 py-2 rounded-lg border transition-colors min-w-[40px] text-center',
            page === currentPage
              ? 'bg-primary text-white border-primary'
              : 'bg-surface border-border hover:bg-gray-50 dark:hover:bg-gray-700 text-text-secondary hover:text-text-primary'
          )}
        >
          {page}
        </Link>
      ))}

      {visiblePages[visiblePages.length - 1] < totalPages && (
        <>
          {visiblePages[visiblePages.length - 1] < totalPages - 1 && (
            <span className="px-2 text-text-secondary">...</span>
          )}
          <Link
            href={createPageUrl(totalPages)}
            className={cn(
              'px-3 py-2 rounded-lg border transition-colors',
              'bg-surface border-border hover:bg-gray-50 dark:hover:bg-gray-700',
              'text-text-secondary hover:text-text-primary'
            )}
          >
            {totalPages}
          </Link>
        </>
      )}

      {currentPage < totalPages && (
        <Link
          href={createPageUrl(currentPage + 1)}
          className="flex items-center px-3 py-2 rounded-lg bg-surface border border-border hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-text-secondary hover:text-text-primary"
        >
          <span className="hidden sm:block">Berikutnya</span>
          <ChevronRight className="w-4 h-4 ml-1" />
        </Link>
      )}
    </div>
  );
}