import Link from 'next/link';
import { EpisodeItem } from '@/lib/api';
import { cn } from '@/lib/utils';

interface EpisodeListProps {
  episodes: EpisodeItem[];
  currentEpisode?: string;
  seriesSlug: string;
  className?: string;
}

export function EpisodeList({ 
  episodes, 
  currentEpisode, 
  seriesSlug,
  className 
}: EpisodeListProps) {
  const sortedEpisodes = [...episodes].sort((a, b) => b.episode_number - a.episode_number);

  return (
    <div className={cn('bg-surface rounded-lg shadow-md', className)}>
      <div className="p-4 border-b border-border">
        <h3 className="text-lg font-semibold text-text-primary">
          Daftar Episode ({episodes.length})
        </h3>
      </div>
      
      <div className="max-h-96 overflow-y-auto">
        {sortedEpisodes.map((episode) => (
          <Link
            key={episode.episode_number}
            href={`/watch/${episode.slug}`}
            className={cn(
              'block px-4 py-3 border-b border-border transition-colors',
              'hover:bg-gray-50 dark:hover:bg-gray-700',
              currentEpisode === episode.slug && 'bg-primary/10 border-primary/20'
            )}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <div className={cn(
                  'w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium',
                  currentEpisode === episode.slug 
                    ? 'bg-primary text-white' 
                    : 'bg-gray-200 dark:bg-gray-700 text-text-secondary'
                )}>
                  {episode.episode_number}
                </div>
                <span className="text-sm font-medium text-text-primary">
                  Episode {episode.episode_number}
                </span>
              </div>
              
              <span className="text-xs text-text-secondary">
                #{episode.episode_number.toString().padStart(3, '0')}
              </span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}