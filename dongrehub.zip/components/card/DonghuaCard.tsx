import Link from 'next/link';
import Image from 'next/image';
import { DonghuaItem } from '@/lib/api';
import { formatTitle, getTypeColor } from '@/lib/utils';
import { cn } from '@/lib/utils';

interface DonghuaCardProps {
  donghua: DonghuaItem;
  size?: 'sm' | 'md' | 'lg';
  showType?: boolean;
  className?: string;
}

export function DonghuaCard({ 
  donghua, 
  size = 'md', 
  showType = true, 
  className 
}: DonghuaCardProps) {
  const formattedTitle = formatTitle(donghua.title);
  
  const sizeClasses = {
    sm: 'aspect-[3/4]',
    md: 'aspect-[3/4]',
    lg: 'aspect-[3/4]'
  };

  const textSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  return (
    <Link 
      href={`/${donghua.slug}`}
      className={cn(
        'group block transition-all duration-300 hover:scale-105',
        className
      )}
    >
      <div className="bg-surface rounded-lg shadow-md overflow-hidden hover:shadow-xl">
        <div className={cn(
          'relative overflow-hidden',
          sizeClasses[size]
        )}>
          <Image
            src={donghua.thumbnail}
            alt={formattedTitle}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-110"
            sizes="(max-width: 640px) 50vw, (max-width: 768px) 33vw, (max-width: 1024px) 25vw, 20vw"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {showType && (
            <div className={cn(
              'type-badge absolute top-2 right-2',
              getTypeColor(donghua.type)
            )}>
              {donghua.type}
            </div>
          )}
          
          <div className="sub-badge absolute top-2 left-2">
            {donghua.sub_badge}
          </div>
          
          <div className="episode-badge absolute bottom-2 left-2">
            {donghua.current_episode}
          </div>
        </div>
        
        <div className="p-3">
          <h3 className={cn(
            'font-semibold text-text-primary line-clamp-2 leading-tight group-hover:text-primary transition-colors',
            textSizes[size]
          )}>
            {formattedTitle}
          </h3>
          
          {donghua.genre && (
            <p className={cn(
              'text-text-secondary mt-1',
              size === 'sm' ? 'text-xs' : 'text-sm'
            )}>
              {donghua.genre}
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}