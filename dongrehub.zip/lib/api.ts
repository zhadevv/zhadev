const API_BASE_URL = 'https://dh.zhadev.my.id/api/v1';

export interface DonghuaItem {
  title: string;
  slug: string;
  thumbnail: string;
  current_episode: string;
  type: string;
  sub_badge: string;
  donghub_url: string;
  genre?: string;
  status?: string;
  alter_title?: string;
}

export interface HomeData {
  popular_today: DonghuaItem[];
  latest_releases: DonghuaItem[];
  recommendation: DonghuaItem[];
  popular_series: DonghuaItem[];
  new_movie: DonghuaItem[];
  genres: Array<{ name: string; slug: string; donghub_url: string }>;
}

export interface SearchResult {
  results: DonghuaItem[];
  pagination: {
    current_page: string;
    next_page: string;
    pages: string[];
  };
}

export interface ScheduleItem {
  title: string;
  slug: string;
  thumbnail: string;
  countdown: string;
  release_time: number;
  current_episode: string;
  type: string;
  donghub_url: string;
}

export interface ScheduleData {
  [key: string]: ScheduleItem[];
}

export interface DetailInfo {
  status: string;
  network: string;
  studio: string;
  released: string;
  duration: string;
  season: string;
  country: string;
  type: string;
  episodes: string;
}

export interface DetailData {
  banner: string;
  thumbnail: string;
  title: string;
  alter_title: string;
  bookmark_count: string;
  synopsis: {
    [key: string]: string;
  };
  info: DetailInfo;
  genres: string[];
  episode_nav: Record<string, unknown>;
  episodes: unknown[];
  tags: string[];
}

export interface EpisodeItem {
  episode_number: number;
  slug: string;
  url: string;
  donghub_url: string;
}

export interface EpisodeData {
  episodes: EpisodeItem[];
}

export interface StreamServer {
  name: string;
  embed_data: string;
  data_index: string;
}

export interface StreamNavigation {
  prev_episode: string;
  next_episode: string;
  all_episodes: string;
}

export interface StreamEpisode {
  title: string;
  episode_number: string;
  url: string;
  thumbnail: string;
}

export interface SeriesInfo {
  title: string;
  status: string;
  type: string;
  episodes: string;
  genres: string[];
  synopsis: {
    [key: string]: string;
  };
}

export interface StreamData {
  title: string;
  episode_number: string;
  thumbnail: string;
  current_embed: string;
  servers: StreamServer[];
  navigation: StreamNavigation;
  episode_list: StreamEpisode[];
  series_info: SeriesInfo;
}

export interface ApiResponse<T> {
  status: number;
  success: boolean;
  author: string;
  data: T;
}

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

class ApiClient {
  private async fetchApi<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    
    if (!response.ok) {
      throw new ApiError(response.status, `HTTP error! status: ${response.status}`);
    }

    const data: ApiResponse<T> = await response.json();
    
    if (!data.success) {
      throw new ApiError(data.status, 'API request failed');
    }

    return data.data;
  }

  async getHome(page?: number): Promise<HomeData> {
    const endpoint = page ? `/home?page=${page}` : '/home';
    return this.fetchApi<HomeData>(endpoint);
  }

  async search(query: string, page?: number): Promise<SearchResult> {
    const endpoint = page 
      ? `/search?s=${encodeURIComponent(query)}&page=${page}`
      : `/search?s=${encodeURIComponent(query)}`;
    return this.fetchApi<SearchResult>(endpoint);
  }

  async getSchedule(): Promise<ScheduleData> {
    return this.fetchApi<ScheduleData>('/schedule');
  }

  async getPopular(page?: number): Promise<SearchResult> {
    const endpoint = page ? `/popular?page=${page}` : '/popular';
    return this.fetchApi<SearchResult>(endpoint);
  }

  async getLatest(page?: number): Promise<SearchResult> {
    const endpoint = page ? `/latest?page=${page}` : '/latest';
    return this.fetchApi<SearchResult>(endpoint);
  }

  async getOngoing(page?: number): Promise<SearchResult> {
    const endpoint = page ? `/ongoing?page=${page}` : '/ongoing';
    return this.fetchApi<SearchResult>(endpoint);
  }

  async getCompleted(page?: number): Promise<SearchResult> {
    const endpoint = page ? `/completed?page=${page}` : '/completed';
    return this.fetchApi<SearchResult>(endpoint);
  }

  async getGenres(slug: string, page?: number): Promise<SearchResult & { genre_title: string }> {
    const endpoint = page 
      ? `/genres/${slug}?page=${page}`
      : `/genres/${slug}`;
    return this.fetchApi<SearchResult & { genre_title: string }>(endpoint);
  }

  async getDetail(slug: string): Promise<DetailData> {
    return this.fetchApi<DetailData>(`/detail/${slug}`);
  }

  async getEpisodes(slug: string): Promise<EpisodeData> {
    return this.fetchApi<EpisodeData>(`/episodes/${slug}`);
  }

  async getStream(slug: string, episode: string): Promise<StreamData> {
    return this.fetchApi<StreamData>(`/stream/${slug}?episode=${episode}`);
  }
}

export const apiClient = new ApiClient();
export { ApiError };