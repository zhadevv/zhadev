import { apiClient } from '@/lib/api';
import { PopularTodaySlider } from '@/components/PopularTodaySlider';
import { HomeSection } from '@/components/HomeSection';
import { SearchInput } from '@/components/SearchInput';

export default async function HomePage() {
  const homeData = await apiClient.getHome();

  return (
    <div className="container py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-text-primary mb-4">
          DongreHub
        </h1>
        <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
          Nonton Donghua Subtitle Indonesia Terlengkap
        </p>
        <div className="max-w-2xl mx-auto">
          <SearchInput />
        </div>
      </div>

      <PopularTodaySlider donghuas={homeData.popular_today} />

      <HomeSection
        title="Rilis Terbaru"
        donghuas={homeData.latest_releases}
        viewAllHref="/latest"
        gridCols={6}
      />

      {homeData.recommendation.length > 0 && (
        <HomeSection
          title="Rekomendasi"
          donghuas={homeData.recommendation}
          gridCols={5}
        />
      )}

      {homeData.new_movie.length > 0 && (
        <HomeSection
          title="Movie Terbaru"
          donghuas={homeData.new_movie}
          gridCols={4}
        />
      )}

      <GenresSection genres={homeData.genres} />
    </div>
  );
}

function GenresSection({ genres }: { genres: Array<{ name: string; slug: string; donghub_url: string }> }) {
  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold text-text-primary mb-6">Genre</h2>
      <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 lg:grid-cols-10 gap-3">
        {genres.map((genre) => (
          <a
            key={genre.slug}
            href={`/genres/${genre.slug}`}
            className="bg-surface hover:bg-primary hover:text-white text-text-primary text-center py-3 px-2 rounded-lg transition-all duration-200 hover:scale-105 text-sm font-medium shadow-sm"
          >
            {genre.name}
          </a>
        ))}
      </div>
    </section>
  );
}