import { apiClient } from '@/lib/api';
import { HomeSection } from '@/components/HomeSection';
import { Pagination } from '@/components/Pagination';
import { notFound } from 'next/navigation';

interface SearchPageProps {
  params: {
    keyword: string;
  };
  searchParams: {
    page?: string;
  };
}

export default async function SearchPage({ params, searchParams }: SearchPageProps) {
  try {
    const currentPage = parseInt(searchParams.page || '1');
    const searchData = await apiClient.search(params.keyword, currentPage);

    return (
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-primary mb-2">
            Hasil Pencarian: {decodeURIComponent(params.keyword)}
          </h1>
          <p className="text-text-secondary">
            Ditemukan {searchData.results.length} hasil untuk "{decodeURIComponent(params.keyword)}"
          </p>
        </div>

        {searchData.results.length > 0 ? (
          <>
            <HomeSection
              title=""
              donghuas={searchData.results}
              gridCols={6}
            />

            {searchData.pagination && (
              <Pagination
                currentPage={currentPage}
                totalPages={10}
                baseUrl={`/search/${params.keyword}`}
                className="mt-8"
              />
            )}
          </>
        ) : (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-text-primary mb-2">
              Tidak ada hasil ditemukan
            </h3>
            <p className="text-text-secondary">
              Coba dengan kata kunci yang berbeda atau lebih spesifik
            </p>
          </div>
        )}
      </div>
    );
  } catch (error) {
    notFound();
  }
}