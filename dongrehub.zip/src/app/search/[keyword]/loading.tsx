import { LoadingSpinner } from '@/components/LoadingSpinner';

export default function Loading() {
  return (
    <div className="container py-8">
      <div className="mb-8">
        <div className="h-8 bg-surface rounded w-96 mb-2 animate-pulse"></div>
        <div className="h-4 bg-surface rounded w-64 animate-pulse"></div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
        {Array.from({ length: 18 }).map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="bg-surface aspect-[3/4] rounded-lg mb-3"></div>
            <div className="h-4 bg-surface rounded mb-2"></div>
            <div className="h-3 bg-surface rounded w-3/4"></div>
          </div>
        ))}
      </div>

      <div className="flex justify-center">
        <LoadingSpinner size="lg" />
      </div>
    </div>
  );
}