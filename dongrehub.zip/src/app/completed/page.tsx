import { apiClient } from '@/lib/api';
import { HomeSection } from '@/components/HomeSection';
import { Pagination } from '@/components/Pagination';

interface CompletedPageProps {
  searchParams: {
    page?: string;
  };
}

export default async function CompletedPage({ searchParams }: CompletedPageProps) {
  const currentPage = parseInt(searchParams.page || '1');
  const completedData = await apiClient.getCompleted(currentPage);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-text-primary mb-2">
          Donghua Tamat
        </h1>
        <p className="text-text-secondary">
          Donghua-donghua yang sudah selesai ditayangkan
        </p>
      </div>

      <HomeSection
        title=""
        donghuas={completedData.results}
        gridCols={6}
      />

      {completedData.pagination && (
        <Pagination
          currentPage={currentPage}
          totalPages={10}
          baseUrl="/completed"
          className="mt-8"
        />
      )}
    </div>
  );
}