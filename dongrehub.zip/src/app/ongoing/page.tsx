import { apiClient } from '@/lib/api';
import { HomeSection } from '@/components/HomeSection';
import { Pagination } from '@/components/Pagination';

interface OngoingPageProps {
  searchParams: {
    page?: string;
  };
}

export default async function OngoingPage({ searchParams }: OngoingPageProps) {
  const currentPage = parseInt(searchParams.page || '1');
  const ongoingData = await apiClient.getOngoing(currentPage);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-text-primary mb-2">
          Sedang Tayang
        </h1>
        <p className="text-text-secondary">
          Donghua-donghua yang masih dalam masa tayang
        </p>
      </div>

      <HomeSection
        title=""
        donghuas={ongoingData.results}
        gridCols={6}
      />

      {ongoingData.pagination && (
        <Pagination
          currentPage={currentPage}
          totalPages={10}
          baseUrl="/ongoing"
          className="mt-8"
        />
      )}
    </div>
  );
}