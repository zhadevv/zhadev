import type { Metadata } from 'next';
import { Fira_Sans, Inter } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@/context/theme-context';
import { NavHeader } from '@/components/NavHeader';

const firaSans = Fira_Sans({
  weight: ['400', '500', '600', '700'],
  subsets: ['latin'],
  variable: '--font-fira-sans',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'DongreHub - Nonton Donghua Subtitle Indonesia',
  description: 'Nonton donghua subtitle Indonesia terbaru dan terlengkap. Streaming Battle Through The Heavens, Renegade Immortal, Perfect World, dan banyak donghua populer lainnya.',
  keywords: 'donghua, anime china, subtitle indonesia, nonton donghua, streaming donghua, battle through the heavens, renegade immortal, perfect world',
  authors: [{ name: 'DongreHub Team' }],
  openGraph: {
    title: 'DongreHub - Nonton Donghua Subtitle Indonesia',
    description: 'Nonton donghua subtitle Indonesia terbaru dan terlengkap',
    type: 'website',
    locale: 'id_ID',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" suppressHydrationWarning className={`${firaSans.variable} ${inter.variable}`}>
      <body className="font-sans">
        <ThemeProvider defaultTheme="dark" storageKey="dongrehub-theme">
          <div className="min-h-screen bg-background transition-colors">
            <NavHeader />
            <main>{children}</main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}

function Footer() {
  return (
    <footer className="bg-surface border-t border-border mt-12">
      <div className="container">
        <div className="py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">D</span>
              </div>
              <span className="text-xl font-bold text-text-primary">DongreHub</span>
            </div>
            
            <div className="flex flex-wrap justify-center gap-6 text-sm text-text-secondary">
              <a href="/about" className="hover:text-primary transition-colors">Tentang</a>
              <a href="/contact" className="hover:text-primary transition-colors">Kontak</a>
              <a href="/privacy" className="hover:text-primary transition-colors">Privacy</a>
              <a href="/terms" className="hover:text-primary transition-colors">Terms</a>
              <a href="/dmca" className="hover:text-primary transition-colors">DMCA</a>
            </div>
          </div>
          
          <div className="border-t border-border mt-6 pt-6 text-center">
            <p className="text-text-secondary text-sm">
              © {new Date().getFullYear()} DongreHub. All rights reserved. 
              Donghua content is provided by third-party sources.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}