import { apiClient } from '@/lib/api';
import { HomeSection } from '@/components/HomeSection';
import { Pagination } from '@/components/Pagination';

interface LatestPageProps {
  searchParams: {
    page?: string;
  };
}

export default async function LatestPage({ searchParams }: LatestPageProps) {
  const currentPage = parseInt(searchParams.page || '1');
  const latestData = await apiClient.getLatest(currentPage);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-text-primary mb-2">
          Rilis Terbaru
        </h1>
        <p className="text-text-secondary">
          Donghua-donghua terbaru yang baru saja dirilis
        </p>
      </div>

      <HomeSection
        title=""
        donghuas={latestData.results}
        gridCols={6}
      />

      {latestData.pagination && (
        <Pagination
          currentPage={currentPage}
          totalPages={10}
          baseUrl="/latest"
          className="mt-8"
        />
      )}
    </div>
  );
}