import { apiClient } from '@/lib/api';
import { HomeSection } from '@/components/HomeSection';
import { Pagination } from '@/components/Pagination';
import { notFound } from 'next/navigation';

interface GenrePageProps {
  params: {
    slug: string;
  };
  searchParams: {
    page?: string;
  };
}

export default async function GenrePage({ params, searchParams }: GenrePageProps) {
  try {
    const currentPage = parseInt(searchParams.page || '1');
    const genreData = await apiClient.getGenres(params.slug, currentPage);

    return (
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-primary mb-2">
            Genre: {genreData.genre_title || params.slug}
          </h1>
          <p className="text-text-secondary">
            Donghua-donghua dengan genre {genreData.genre_title || params.slug}
          </p>
        </div>

        <HomeSection
          title=""
          donghuas={genreData.results}
          gridCols={6}
        />

        {genreData.pagination && (
          <Pagination
            currentPage={currentPage}
            totalPages={10}
            baseUrl={`/genres/${params.slug}`}
            className="mt-8"
          />
        )}
      </div>
    );
  } catch (error) {
    notFound();
  }
}