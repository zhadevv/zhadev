export async function GET() {
  const robots = `
User-agent: *
Allow: /
Disallow: /

Sitemap: https://dongrehub.vercel.app/sitemap.xml
  `.trim();

  return new Response(robots, {
    headers: {
      'Content-Type': 'text/plain',
    },
  });
}