import { apiClient } from '@/lib/api';
import { HomeSection } from '@/components/HomeSection';
import { Pagination } from '@/components/Pagination';

interface PopularPageProps {
  searchParams: {
    page?: string;
  };
}

export default async function PopularPage({ searchParams }: PopularPageProps) {
  const currentPage = parseInt(searchParams.page || '1');
  const popularData = await apiClient.getPopular(currentPage);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-text-primary mb-2">
          Donghua Populer
        </h1>
        <p className="text-text-secondary">
          Donghua-donghua paling populer dan banyak ditonton
        </p>
      </div>

      <HomeSection
        title=""
        donghuas={popularData.results}
        gridCols={6}
      />

      {popularData.pagination && (
        <Pagination
          currentPage={currentPage}
          totalPages={10}
          baseUrl="/popular"
          className="mt-8"
        />
      )}
    </div>
  );
}