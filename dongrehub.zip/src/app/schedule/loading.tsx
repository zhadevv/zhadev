import { LoadingSpinner } from '@/components/LoadingSpinner';

export default function Loading() {
  return (
    <div className="container py-8">
      <div className="mb-8">
        <div className="h-8 bg-surface rounded w-48 mb-2 animate-pulse"></div>
        <div className="h-4 bg-surface rounded w-64 animate-pulse"></div>
      </div>

      <div className="space-y-8">
        {Array.from({ length: 7 }).map((_, dayIndex) => (
          <div key={dayIndex} className="bg-surface rounded-lg shadow-md overflow-hidden animate-pulse">
            <div className="h-16 bg-gray-300 dark:bg-gray-700"></div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {Array.from({ length: 4 }).map((_, itemIndex) => (
                  <div key={itemIndex} className="bg-background rounded-lg p-4 border border-border">
                    <div className="flex space-x-4">
                      <div className="flex-shrink-0 w-20 h-28 bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded"></div>
                        <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
                        <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-1/2"></div>
                        <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-2/3"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <LoadingSpinner size="lg" />
      </div>
    </div>
  );
}