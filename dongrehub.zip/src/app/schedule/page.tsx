import { apiClient } from '@/lib/api';
import { DonghuaCard } from '@/components/card/DonghuaCard';
import { formatDate } from '@/lib/utils';
import { Calendar, Clock } from 'lucide-react';

export default async function SchedulePage() {
  const scheduleData = await apiClient.getSchedule();
  
  const days = [
    'Sunday', 'Monday', 'Tuesday', 'Wednesday', 
    'Thursday', 'Friday', 'Saturday'
  ];

  const today = new Date().getDay();
  const orderedDays = [
    ...days.slice(today),
    ...days.slice(0, today)
  ];

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-text-primary mb-2">
          Jadwal Tayang
        </h1>
        <p className="text-text-secondary">
          Jadwal rilis episode donghua berdasarkan hari
        </p>
      </div>

      <div className="space-y-8">
        {orderedDays.map((day) => {
          const daySchedule = scheduleData[day] || [];
          if (daySchedule.length === 0) return null;

          return (
            <div key={day} className="bg-surface rounded-lg shadow-md overflow-hidden">
              <div className="bg-primary text-white px-6 py-4">
                <h2 className="text-xl font-bold flex items-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span>{getIndonesianDay(day)}</span>
                </h2>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {daySchedule.map((item) => (
                    <ScheduleCard key={item.slug} item={item} />
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ScheduleCard({ item }: { item: any }) {
  const releaseDate = formatDate(item.release_time);
  
  return (
    <div className="bg-background rounded-lg p-4 border border-border">
      <div className="flex space-x-4">
        <div className="flex-shrink-0 w-20 h-28 relative rounded-lg overflow-hidden">
          <img
            src={item.thumbnail}
            alt={item.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-text-primary line-clamp-2 mb-2">
            {item.title}
          </h3>
          
          <div className="space-y-1 text-sm text-text-secondary">
            <div className="flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>Episode {item.current_episode}</span>
            </div>
            
            {item.countdown && (
              <div className="text-xs">
                Countdown: {formatCountdown(parseInt(item.countdown))}
              </div>
            )}
            
            <div className="text-xs">
              {releaseDate}
            </div>
          </div>
          
          <a
            href={`/${item.slug}`}
            className="inline-block mt-2 text-primary hover:text-primary/80 text-sm font-medium"
          >
            Lihat Detail →
          </a>
        </div>
      </div>
    </div>
  );
}

function getIndonesianDay(englishDay: string): string {
  const days: { [key: string]: string } = {
    'Sunday': 'Minggu',
    'Monday': 'Senin',
    'Tuesday': 'Selasa',
    'Wednesday': 'Rabu',
    'Thursday': 'Kamis',
    'Friday': 'Jumat',
    'Saturday': 'Sabtu'
  };
  return days[englishDay] || englishDay;
}

function formatCountdown(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (hours > 0) {
    return `${hours}j ${minutes}m`;
  }
  return `${minutes}m`;
}