import { notFound } from 'next/navigation';
import { apiClient } from '@/lib/api';
import { VideoPlayer } from '@/components/VideoPlayer';
import { EpisodeList } from '@/components/card/EpisodeList';
import Link from 'next/link';
import { ChevronLeft, ChevronRight, List } from 'lucide-react';
import { formatTitle } from '@/lib/utils';

interface WatchPageProps {
  params: {
    episodeSlug: string;
  };
}

export default async function WatchPage({ params }: WatchPageProps) {
  try {
    const seriesSlug = params.episodeSlug.split('-episode-')[0];
    const streamData = await apiClient.getStream(seriesSlug, params.episodeSlug);
    const episodesData = await apiClient.getEpisodes(seriesSlug);

    const currentEpisodeIndex = episodesData.episodes.findIndex(
      ep => ep.slug === params.episodeSlug
    );

    const currentEpisode = episodesData.episodes[currentEpisodeIndex];
    const nextEpisode = episodesData.episodes[currentEpisodeIndex + 1];
    const prevEpisode = episodesData.episodes[currentEpisodeIndex - 1];

    return (
      <div className="container py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-3/4">
            <div className="mb-4">
              <nav className="flex items-center space-x-2 text-sm text-text-secondary mb-4">
                <Link href="/" className="hover:text-primary transition-colors">
                  Home
                </Link>
                <span>›</span>
                <Link href={`/${seriesSlug}`} className="hover:text-primary transition-colors">
                  {formatTitle(streamData.series_info.title)}
                </Link>
                <span>›</span>
                <span className="text-text-primary">
                  Episode {streamData.episode_number}
                </span>
              </nav>

              <h1 className="text-2xl font-bold text-text-primary mb-2">
                {streamData.title}
              </h1>
            </div>

            <VideoPlayer streamData={streamData} className="mb-6" />

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              {prevEpisode && (
                <Link
                  href={`/watch/${prevEpisode.slug}`}
                  className="flex items-center justify-center space-x-2 px-6 py-3 bg-surface border border-border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex-1"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Episode {prevEpisode.episode_number}</span>
                </Link>
              )}

              <Link
                href={`/${seriesSlug}`}
                className="flex items-center justify-center space-x-2 px-6 py-3 bg-surface border border-border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex-1"
              >
                <List className="w-4 h-4" />
                <span>Daftar Episode</span>
              </Link>

              {nextEpisode && (
                <Link
                  href={`/watch/${nextEpisode.slug}`}
                  className="flex items-center justify-center space-x-2 px-6 py-3 bg-surface border border-border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex-1"
                >
                  <span>Episode {nextEpisode.episode_number}</span>
                  <ChevronRight className="w-4 h-4" />
                </Link>
              )}
            </div>

            {streamData.series_info && (
              <div className="bg-surface rounded-lg p-6 border border-border">
                <h2 className="text-xl font-bold text-text-primary mb-4">
                  Tentang Series
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-text-secondary">Judul</div>
                    <div className="font-medium text-text-primary">
                      {streamData.series_info.title}
                    </div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Status</div>
                    <div className="font-medium text-text-primary">
                      {streamData.series_info.status}
                    </div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Tipe</div>
                    <div className="font-medium text-text-primary">
                      {streamData.series_info.type}
                    </div>
                  </div>
                  <div>
                    <div className="text-text-secondary">Total Episode</div>
                    <div className="font-medium text-text-primary">
                      {streamData.series_info.episodes}
                    </div>
                  </div>
                </div>

                {Object.values(streamData.series_info.synopsis).some(s => s.trim()) && (
                  <div className="mt-4">
                    <div className="text-text-secondary mb-2">Sinopsis</div>
                    <p className="text-text-primary leading-relaxed">
                      {Object.values(streamData.series_info.synopsis)[0]}
                    </p>
                  </div>
                )}

                {streamData.series_info.genres.length > 0 && (
                  <div className="mt-4">
                    <div className="text-text-secondary mb-2">Genre</div>
                    <div className="flex flex-wrap gap-2">
                      {streamData.series_info.genres.map((genre) => (
                        <span
                          key={genre}
                          className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium"
                        >
                          {genre}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="lg:w-1/4">
            <EpisodeList
              episodes={episodesData.episodes}
              currentEpisode={params.episodeSlug}
              seriesSlug={seriesSlug}
            />
          </div>
        </div>
      </div>
    );
  } catch (error) {
    notFound();
  }
}