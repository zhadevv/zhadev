export default function Loading() {
  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 animate-pulse">
          <div className="h-8 bg-surface rounded w-64 mb-2"></div>
          <div className="h-4 bg-surface rounded w-96"></div>
        </div>

        <div className="bg-surface rounded-lg shadow-lg overflow-hidden animate-pulse">
          <div className="h-16 bg-gray-300 dark:bg-gray-700"></div>
          <div className="p-6 space-y-6">
            <div className="flex items-center space-x-6">
              <div className="w-24 h-24 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-32"></div>
                <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-48"></div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i}>
                  <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-24 mb-2"></div>
                  <div className="h-12 bg-gray-300 dark:bg-gray-700 rounded"></div>
                </div>
              ))}
            </div>

            <div className="h-24 bg-gray-300 dark:bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-300 dark:bg-gray-700 rounded w-32 ml-auto"></div>
          </div>
        </div>
      </div>
    </div>
  );
}