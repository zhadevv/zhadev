import { LoadingSpinner } from '@/components/LoadingSpinner';

export default function Loading() {
  return (
    <div className="container py-8">
      <div className="bg-surface rounded-lg shadow-lg overflow-hidden mb-8 animate-pulse">
        <div className="h-64 md:h-80 lg:h-96 bg-gray-300 dark:bg-gray-700"></div>
        
        <div className="p-6 md:p-8">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-1/4">
              <div className="aspect-[3/4] bg-gray-300 dark:bg-gray-700 rounded-lg"></div>
            </div>

            <div className="lg:w-3/4 space-y-4">
              <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/2"></div>
              
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-6 bg-gray-300 dark:bg-gray-700 rounded-full w-20"></div>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-gray-300 dark:bg-gray-700 rounded"></div>
                    <div className="space-y-2">
                      <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-16"></div>
                      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-24"></div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full"></div>
                <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full"></div>
                <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    </div>
  );
}