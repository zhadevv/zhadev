import { notFound } from 'next/navigation';
import { apiClient } from '@/lib/api';
import Image from 'next/image';
import Link from 'next/link';
import { EpisodeList } from '@/components/card/EpisodeList';
import { Calendar, Clock, Play, Tv, MapPin, Users } from 'lucide-react';
import { formatTitle, formatDate, parseDuration, formatDuration } from '@/lib/utils';

interface DetailPageProps {
  params: {
    slug: string;
  };
}

export default async function DetailPage({ params }: DetailPageProps) {
  try {
    const detailData = await apiClient.getDetail(params.slug);
    const episodesData = await apiClient.getEpisodes(params.slug);

    const formattedTitle = formatTitle(detailData.title);
    const durationMinutes = parseDuration(detailData.info.duration);

    return (
      <div className="container py-8">
        <div className="bg-surface rounded-lg shadow-lg overflow-hidden mb-8">
          {detailData.banner && (
            <div className="relative h-64 md:h-80 lg:h-96">
              <Image
                src={detailData.banner}
                alt={formattedTitle}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent" />
            </div>
          )}

          <div className="p-6 md:p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="lg:w-1/4">
                <div className="relative aspect-[3/4] rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src={detailData.thumbnail}
                    alt={formattedTitle}
                    fill
                    className="object-cover"
                  />
                </div>
              </div>

              <div className="lg:w-3/4">
                <div className="flex flex-col h-full">
                  <div className="mb-4">
                    <h1 className="text-3xl md:text-4xl font-bold text-text-primary mb-2">
                      {formattedTitle}
                    </h1>
                    {detailData.alter_title && (
                      <p className="text-text-secondary text-lg">
                        {detailData.alter_title}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {detailData.genres.map((genre) => (
                      <Link
                        key={genre}
                        href={`/genres/${genre.toLowerCase()}`}
                        className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium hover:bg-primary/20 transition-colors"
                      >
                        {genre}
                      </Link>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <InfoItem
                      icon={<Tv className="w-4 h-4" />}
                      label="Tipe"
                      value={detailData.info.type}
                    />
                    <InfoItem
                      icon={<Play className="w-4 h-4" />}
                      label="Status"
                      value={detailData.info.status}
                    />
                    <InfoItem
                      icon={<Clock className="w-4 h-4" />}
                      label="Durasi"
                      value={formatDuration(durationMinutes)}
                    />
                    <InfoItem
                      icon={<Calendar className="w-4 h-4" />}
                      label="Rilis"
                      value={detailData.info.released.replace('Released on:', '')}
                    />
                    {detailData.info.studio && (
                      <InfoItem
                        icon={<MapPin className="w-4 h-4" />}
                        label="Studio"
                        value={detailData.info.studio}
                      />
                    )}
                    {detailData.info.network && (
                      <InfoItem
                        icon={<Users className="w-4 h-4" />}
                        label="Network"
                        value={detailData.info.network}
                      />
                    )}
                  </div>

                  {detailData.bookmark_count && (
                    <div className="mb-6">
                      <p className="text-text-secondary">
                        {detailData.bookmark_count}
                      </p>
                    </div>
                  )}

                  {Object.values(detailData.synopsis).some(s => s.trim()) && (
                    <div className="mb-6">
                      <h3 className="text-xl font-semibold text-text-primary mb-3">
                        Sinopsis
                      </h3>
                      <div className="prose prose-gray dark:prose-invert max-w-none">
                        {Object.values(detailData.synopsis).map((paragraph, index) => (
                          paragraph.trim() && (
                            <p key={index} className="text-text-primary leading-relaxed mb-3">
                              {paragraph}
                            </p>
                          )
                        ))}
                      </div>
                    </div>
                  )}

                  {episodesData.episodes.length > 0 && (
                    <div className="mt-auto">
                      <Link
                        href={`/watch/${episodesData.episodes[0].slug}`}
                        className="btn btn-primary inline-flex items-center space-x-2"
                      >
                        <Play className="w-4 h-4" />
                        <span>Tonton Sekarang</span>
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {episodesData.episodes.length > 0 && (
          <EpisodeList
            episodes={episodesData.episodes}
            seriesSlug={params.slug}
          />
        )}
      </div>
    );
  } catch (error) {
    notFound();
  }
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center space-x-3">
      <div className="text-primary">
        {icon}
      </div>
      <div>
        <div className="text-sm text-text-secondary">{label}</div>
        <div className="text-text-primary font-medium">{value}</div>
      </div>
    </div>
  );
}